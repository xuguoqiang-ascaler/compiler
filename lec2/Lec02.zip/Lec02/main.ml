

let s = X86.string_of_asm (X86.p2 5)

;; print_string s
